package com.dd186.admin.Domain.Order;

public enum OrderStatus {
        PENDING,
        READY,
        COLLECTED,
        EDITING
}

