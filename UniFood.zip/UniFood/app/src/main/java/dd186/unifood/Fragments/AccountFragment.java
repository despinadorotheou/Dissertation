package dd186.unifood.Fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import dd186.unifood.Entities.Order;
import dd186.unifood.Entities.User;
import dd186.unifood.Main;
import dd186.unifood.R;

public class AccountFragment extends Fragment {

    @SuppressLint("SetTextI18n")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, null );
        Main main = (Main) getActivity();
        assert main != null;
        if (Main.pendingOrder!= null){
            Button orderStatus = view.findViewById(R.id.orderStatus_btn);
            orderStatus.setVisibility(View.VISIBLE);
        }
        TextView name = view.findViewById(R.id.name_account);
        name.setText(Main.user.getName() + " " + Main.user.getLastName());
        return view;
    }


}
